# 专利维护
class Infomanager(QMainWindow, infomanager.Ui_MainWindow):
    global op,co,table1


    def __init__(self, parent=None):
        global op,co
        op=''
        co=''
        super(Infomanager, self).__init__(parent)
        infomanager = self.setupUi(self)

        self.pushButton_6.clicked.connect(self.add)
        self.pushButton.clicked.connect(self.modify)
        self.pushButton_5.clicked.connect(self.delet)
        self.pushButton_9.clicked.connect(self.clear)   #清除按钮

        # self.pushButton_3.clicked.connect(self.pre)
        # self.pushButton_4.clicked.connect(self.next)
        self.pushButton_2.clicked.connect(self.confirm)

        self.select.clicked.connect(self.close)
        self.geneinfo.clicked.connect(self.close)
        self.genequery.clicked.connect(self.close)
        self.usermanager.clicked.connect(self.close)
        table=self.update1()

        self.timer = QTimer(self)  # 初始化一个定时器
        self.timer.timeout.connect(self.operate)  # 计时结束调用operate()方法
        self.timer.start(20)  # 设置计时间隔并启动




    def update1(self):
        global op, co
        table = QTableWidget()
        table.setColumnCount(8)
        table.setColumnWidth(0, 50)
        table.setColumnWidth(1, 50)
        table.setColumnWidth(2, 100)
        table.setColumnWidth(3, 50)
        table.setColumnWidth(4, 50)
        table.setColumnWidth(5, 100)
        table.setColumnWidth(6, 100)
        table.setColumnWidth(7, 100)
        try:
            sql = 'select * from patent_data'
            cus = conn.cursor()
            cus.execute(sql)
            content = cus.fetchall()
            rows = len(content)
            table.setRowCount(rows)
            for i in range(rows):
                k = 0
                for j in content[i]:
                    table.setItem(i, k, QTableWidgetItem(str(content[i][j])))
                    k += 1
        except:
            print('wrong')
        horizontalHeader = ['Id', 'Jurisdiction ', 'patent number', 'date of publication', 'year of publication', 'invention name', 'applicant', 'inventor']
        table.setHorizontalHeaderLabels(horizontalHeader)
        self.scrollArea.setWidget(table)


        return table





    def add(self):
        global op
        op='add'
        print("add")

    def modify(self):
        global op
        op='change'
        print("modify")

    def delet(self):
        global op
        op='del'
        print("delete")

    def pre(self):
        global op
        op='up'
        print("the last one")

    def next(self):
        global op
        op='down'
        print("the next one")




    def confirm(self):
        global op
        ID = self.ID.text()
        patent_number = self.PublicationNumber.text()
        patent_name = self.Title.text()
        patent_firm = self.Applicants.text()
        patent_inventor = self.lineEdit_6.text()
        patent_date = self.PublicationDate.text()
        publication_year = self.PublicationYear.text()
        print(ID + patent_number + patent_name + patent_firm + patent_inventor + patent_date + publication_year)

        Jurisdiction=self.Jurisdiction_2.currentText()

        content1={'Id':False, 'Jurisdiction':False, 'Publication_Number':False, 'Publication_Date':False, 'Publication_Year':False, 'Title':False, 'Applicants':False, 'Inventors':False}
        content=(ID,Jurisdiction,patent_number,patent_date,publication_year,patent_name,patent_firm,patent_inventor)
        x=0
        try:
            for j in content1:
                content1[j]=content[x]
                x+=1
        except:
            print()



        if op=='add':
            try:

                sql = "insert into patent_data(Id, Jurisdiction, Publication_Number, Publication_Date, " \
                      "Publication_Year, Title, Applicants, Inventors) " \
                      "values (%s, %s, %s, %s, %s, %s, %s, %s)"

                cus1 = conn.cursor()
                cus1.execute(sql,content)
                conn.commit()
                cus1.close()
                msg_box = QMessageBox.information(self, "note", "success", QMessageBox.Yes)
            except:
                print('wrong')
                msg_box = QMessageBox.warning(self, "warn", "fail", QMessageBox.Cancel)
            self.update1()
            # msg_box = QMessageBox.information(self, "提示", "增加成功", QMessageBox.Yes)

        if op=='del':
            pp=[]
            sql = 'DELETE FROM patent_data WHERE'
            ks = 0
            try:
                for j in content1:
                    if j=='Publication_Date' and content1[j]=='2000/1/1':
                        continue
                    if content1[j]:
                        if ks>0:
                            sql=sql+' and'
                        sql+=' '+str(j)+'=%s'
                        pp.append(content1[j])
                        ks+=1
            except:
                print('wrong')



            print(sql,pp)
            try:

                cus1 = conn.cursor()
                cus1.execute(sql,pp)
                conn.commit()
                cus1.close()
            except:
                print('wrong')
            op=''
            self.update1()




        if op=='change':
            sql='UPDATE patent_data SET'
            ks=0
            pp=[]
            try:
                for j in content1:
                    if j=='Publication_Date' and content1[j]=='2000/1/1':
                        continue

                    if content1[j] and j!='Id':

                        if ks>0:
                            sql=sql+','
                        sql+=' '+str(j)+'=%s'
                        pp.append(content1[j])
                        ks+=1
                sql+=' where id=%s'
                print(sql, pp)
                pp.append(ID)
                cus1 = conn.cursor()
                cus1.execute(sql, pp)
                conn.commit()
                cus1.close()
                op = ''
            except:
                print('wrong')
            self.update1()





        self.update1()








        print("check")

    def select1(self):
        self.close()
        print("search")


msg_box = QMessageBox.information(self, "note", "success", QMessageBox.Yes)
msg_box = QMessageBox.critical(self, "wrong", "fail", QMessageBox.Cancel)
msg_box = QMessageBox.warning(self, "warn", "please check again", QMessageBox.Cancel)
msg_box = QMessageBox.information(self, "note", "对不起，您没有此权限！", QMessageBox.Yes)


# sql = "insert into patent_data(Id, Jurisdiction, Publication_Number, Publication_Date, " \
                #       "Publication_Year, Title, Applicants, Inventors) " \
                #       "values (%s, %s, %s, %s, %s, %s, %s, %s)"

                sql = "insert into patent_data(Jurisdiction, Publication_Number, Publication_Date, " \
                      "Publication_Year, Title, Applicants, Inventors) " \
                      "values ( %s, %s, %s, %s, %s, %s, %s)"

                cus1 = conn.cursor()

                newcc=content[1:]


                cus1.execute(sql,newcc)





