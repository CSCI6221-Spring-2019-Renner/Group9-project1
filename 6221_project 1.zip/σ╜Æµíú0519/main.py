# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/Users/luxx/Desktop/wjy/窗口/专利信息批量导入.ui'
#
# Created by: PyQt5 UI code generator 5.6
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets


from PyQt5 import QtCore, QtWidgets,QtGui
import lawquery
from PyQt5 import QtGui

from PyQt5.QtWidgets import QApplication , QMainWindow,QFileDialog,QMessageBox
import sys,pdb

import login, signup, infoimport, infoquery, geneinfo, genequery, geneimport, usermanager, mainquery, stastics, lawimport, myinfo
from Bio import SeqIO
import infomanager
import pymysql
from PyQt5.QtCore import QTimer
from openpyxl import load_workbook
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QWidget, QApplication, QDesktopWidget, QTableWidget, QHBoxLayout, QTableWidgetItem, \
QComboBox, QFrame
from PyQt5.QtGui import QFont, QColor, QBrush, QPixmap
import xlrd
import pymysql
from datetime import datetime
from xlrd import xldate_as_tuple

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.pyplot import savefig


from hashlib import sha1
import hashlib
global infoquerygobal,loginWindowgobal,infoWindowgobal,geneinfo_gobal,geneinfo_gobal,genequery_gobal,geneimport_gobal,usermanager_gobal
global op,co,table1,gop,uop
global files,files2
table1=1

config = {
          'host':'127.0.0.1',
          'port':3306,
          'user':'root',
          'password':'123',
          'db':'wjy1',
          'charset':'utf8mb4',
          'cursorclass':pymysql.cursors.DictCursor,
          }
conn = pymysql.connect(**config)



def read(file):

    #seqNum就是存序列中包含几个片段的变量
    seqNum=0
    #下面是biopython的内容，具体不是特别清楚原理，但是大致效果看截图就好了。file应该可以改成某个固定文件夹，没改成功(SeqIO.parse(地址+'/'+file,'fasta'))
    for x in SeqIO.parse(file,'fasta'):
        seqNum+=1
    #接下来是处理文件名，文件名有一下信息，专利号和type
    '''
    str.split(x)这个函数是把str以x为中间符号划分开，然后每一段作为元素存在一个数组里
    例如'abcdas'.split('a')返回的结果就是['', 'bcd', 's']
    '''
    #a存储文件名
    a = file
    #a.split('.')[0]把a文件名以'.'分割就会得到例如tt.txt变成['tt','txt']的结果
    #然后取列表第一个就是不带后缀的文件名
    b = a.split('.')[0]
    #接下来要判断b中是否带着(有的话，就是后两种类型，没有的话就是第一种
    #判断方法就是先按'('分割，有的话，例如US_9023829_B2 (1)就会比变成数组['US_9023829_B2 ','1)']
    #没有的话，例如US_9023829_B2,就会比变成数组['US_9023829_B2 ']
    c = b.split('(')
    #这个时候在分割好的数组末尾添加一个0，有(的文件名数组c[1]的地方是类似1）或者2)的元素，没有(的则为0
    c.append(0)
    #同时c[0]就是专利名赋值给patentNum
    patentNum=c[0]
    seqType=None
    #检查c[1]是否为0，为0就是peptides
    if c[1]==0:
        seqType='peptides'
    else:
        #否者处理 1/2)这样的字符串，用split把）去掉看数字是多少
        num=int(c[1].split(')')[0])
        if num==1:
            seqType='nucleotides'
        else:
            seqType='RNAs'
    #最后把文件里的内容读进来就好了，改成固定文件夹失败了(SeqIO.parse(地址+'/'+file,'fasta'))
    seqContent=open(file).read()
    print(file+' finish')
    ppp=patentNum.split('/')
    print(ppp)
    return (ppp[-1:][0],seqType,seqNum,seqContent,file)




class LoginWindow(QMainWindow, login.Ui_MainWindow):
    def __init__(self, parent=None):
        super(LoginWindow, self).__init__(parent)
        login = self.setupUi(self)
    # 判断用户名密码
    def if_Login(self):
        username = self.lineEdit.text()
        password = self.lineEdit_2.text()
        print(username + password)
        try:
            name=username
            pwd=password
            res = [name]
            # 对密码加密
            m = sha1()
            s = m.update(pwd.encode("utf-8"))
            print(s)
            pwd2 = sha1(pwd.encode('utf-8')).hexdigest()
            # 根据用户名查询密码

            sql = 'select * from (userinfo) where UserName=%s'
            sql1 = 'select * from (userinfo) where UserName=%s'
            cus1 = conn.cursor()
            cus1.execute(sql, res)
            psw = cus1.fetchall()
            cus2 = conn.cursor()
            cus2.execute(sql1, res)
            type = cus2.fetchall()
            print(pwd,'ds')
            if psw == ():
                print("user's name is incorrect")
                msg_box = QMessageBox.information(self, "wrong", "User does not exist", QMessageBox.Yes)

            elif psw[0]['Passwd'] == pwd2:
                self.close()
                f = open('cookies.txt', 'w')
                f.write(str(psw[0]))
                f.close()
                print("success")

            else:
                print("fail")
                msg_box = QMessageBox.information(self, "wrong", "wrong password")

            conn.commit()
            cus1.close()
            cus2.close()
        except:
            return



# 专利维护
class Infomanager(QMainWindow, infomanager.Ui_MainWindow):
    global op,co,table1


    def __init__(self, parent=None):
        global op,co
        op=''
        co=''
        super(Infomanager, self).__init__(parent)
        infomanager = self.setupUi(self)

        self.pushButton_6.clicked.connect(self.add)
        self.pushButton.clicked.connect(self.modify)
        self.pushButton_5.clicked.connect(self.delet)
        self.pushButton_9.clicked.connect(self.clear)   #清除按钮

        # self.pushButton_3.clicked.connect(self.pre)
        # self.pushButton_4.clicked.connect(self.next)
        self.pushButton_2.clicked.connect(self.confirm)

        self.select.clicked.connect(self.close)
        self.geneinfo.clicked.connect(self.close)
        self.genequery.clicked.connect(self.close)
        self.usermanager.clicked.connect(self.close)
        table=self.update1()

        self.timer = QTimer(self)  # 初始化一个定时器
        self.timer.timeout.connect(self.operate)  # 计时结束调用operate()方法
        self.timer.start(20)  # 设置计时间隔并启动


        # self.pushButton_9.clicked.connect(self.clear)   #清除按钮
    # 添加一个清除按钮
    def clear(self):
        try:
            self.ID.setText("")
            self.PublicationNumber.setText("")
            # self.Jurisdiction_2.setItemText(" ")
            self.Jurisdiction_2.setCurrentIndex(0)
            # self.PublicationData.setText("")
            self.PublicationYear.setText("")
            self.Title.setText("")
            self.Applicants.setText("")
            self.lineEdit_6.setText("")
            print("clear")
        except:
            print("erro")

    #当前用户
    def operate(self):
        f=open('cookies.txt','r')
        x=eval(f.read())['UserName']
        if x!=0:
            self.label_0.setText(x)
            self.timer.stop()


    def update1(self):
        global op, co
        table = QTableWidget()
        table.setColumnCount(8)
        table.setColumnWidth(0, 50)
        table.setColumnWidth(1, 50)
        table.setColumnWidth(2, 100)
        table.setColumnWidth(3, 50)
        table.setColumnWidth(4, 50)
        table.setColumnWidth(5, 100)
        table.setColumnWidth(6, 100)
        table.setColumnWidth(7, 100)
        try:
            sql = 'select * from patent_data'
            cus = conn.cursor()
            cus.execute(sql)
            content = cus.fetchall()
            rows = len(content)
            table.setRowCount(rows)
            for i in range(rows):
                k = 0
                for j in content[i]:
                    table.setItem(i, k, QTableWidgetItem(str(content[i][j])))
                    k += 1
        except:
            print('wrong')
        horizontalHeader = ['Id', 'Jurisdiction ', 'patent number', 'date of publication', 'year of publication', 'invention name', 'applicant', 'inventor']
        table.setHorizontalHeaderLabels(horizontalHeader)
        self.scrollArea.setWidget(table)


        return table





    def add(self):
        global op
        op='add'
        print("add")

    def modify(self):
        global op
        op='change'
        print("modify")

    def delet(self):
        global op
        op='del'
        print("delete")

    def pre(self):
        global op
        op='up'
        print("the last one")

    def next(self):
        global op
        op='down'
        print("the next one")




    def confirm(self):
        global op
        ID = self.ID.text()
        patent_number = self.PublicationNumber.text()
        patent_name = self.Title.text()
        patent_firm = self.Applicants.text()
        patent_inventor = self.lineEdit_6.text()
        patent_date = self.PublicationDate.text()
        publication_year = self.PublicationYear.text()
        print(ID + patent_number + patent_name + patent_firm + patent_inventor + patent_date + publication_year)

        Jurisdiction=self.Jurisdiction_2.currentText()

        content1={'Id':False, 'Jurisdiction':False, 'Publication_Number':False, 'Publication_Date':False, 'Publication_Year':False, 'Title':False, 'Applicants':False, 'Inventors':False}
        content=(ID,Jurisdiction,patent_number,patent_date,publication_year,patent_name,patent_firm,patent_inventor)
        x=0
        try:
            for j in content1:
                content1[j]=content[x]
                x+=1
        except:
            print()
            msg_box = QMessageBox.critical(self, "wrong", "failed", QMessageBox.Yes)



        if op=='add':
            try:

                sql = "insert into patent_data(Id, Jurisdiction, Publication_Number, Publication_Date, " \
                      "Publication_Year, Title, Applicants, Inventors) " \
                      "values (%s, %s, %s, %s, %s, %s, %s, %s)"

                cus1 = conn.cursor()
                cus1.execute(sql,content)
                conn.commit()
                cus1.close()
                msg_box = QMessageBox.information(self, "note", "success", QMessageBox.Yes)
            except:
                print('wrong')
                msg_box = QMessageBox.warning(self, "warning", "please check again", QMessageBox.Cancel)
            self.update1()
            # msg_box = QMessageBox.information(self, "提示", "增加成功", QMessageBox.Yes)

        if op=='del':
            pp=[]
            sql = 'DELETE FROM patent_data WHERE'
            ks = 0
            try:
                for j in content1:
                    if j=='Publication_Date' and content1[j]=='2000/1/1':
                        continue
                    if content1[j]:
                        if ks>0:
                            sql=sql+' and'
                        sql+=' '+str(j)+'=%s'
                        pp.append(content1[j])
                        ks+=1

            except:
                print('wrong')




            print(sql,pp)
            try:

                cus1 = conn.cursor()
                cus1.execute(sql,pp)
                conn.commit()
                cus1.close()
                msg_box = QMessageBox.information(self, "note", "success", QMessageBox.Yes)
            except:
                print('wrong')
                msg_box = QMessageBox.critical(self, "wromg", "fail", QMessageBox.Cancel)
            op=''
            self.update1()




        if op=='change':
            sql='UPDATE patent_data SET'
            ks=0
            pp=[]
            try:
                for j in content1:
                    if j=='Publication_Date' and content1[j]=='2000/1/1':
                        continue

                    if content1[j] and j!='Id':

                        if ks>0:
                            sql=sql+','
                        sql+=' '+str(j)+'=%s'
                        pp.append(content1[j])
                        ks+=1
                sql+=' where id=%s'
                print(sql, pp)
                pp.append(ID)
                cus1 = conn.cursor()
                cus1.execute(sql, pp)
                conn.commit()
                cus1.close()
                op = ''
                msg_box = QMessageBox.information(self, "note", "success", QMessageBox.Yes)

            except:
                print('wrong')
                msg_box = QMessageBox.critical(self, "wrong", "fail", QMessageBox.Cancel)

            self.update1()





        self.update1()








        print("check")

    def select1(self):
        self.close()
        print("search")















# 注册界面
class Register(QMainWindow, signup.Ui_MainWindow):
    def __init__(self, parent=None):
        super(Register, self).__init__(parent)
        register = self.setupUi(self)
        self.pushButton_2.clicked.connect(self.rigster)
    
    def rigster(self):

        name = self.ID.text()
        password = self.PublicationNumber_2.text()
        re_password = self.PublicationNumber.text()
        mail = self.Applicants_2.text()
        tel = self.Applicants.text()
        sex=self.comboBox.currentText()
        if sex=='male':
            sex=1
        else:
            sex=2


        if password == re_password:
            try:
                cus1 = conn.cursor()
                sql = "insert into userinfo(UserName, Passwd, Sex, Email, Tel,Type) values(%s,%s,%s,%s,%s,%s)"
                pwd = hashlib.sha1 (password.encode ("utf-8")).hexdigest ()
                print(pwd)
                if str(tel)=='013522':
                    res = [name, pwd, sex, mail, tel,2]
                else:
                    res = [name, pwd, sex, mail, tel, 1]
                print(res)
                cus1.execute(sql, res)
                conn.commit()
                cus1.close()
                self.close()
                msg_box = QMessageBox.information(self, "note", "success! please reture for login", QMessageBox.Yes)
            except:
                return
        else:
            msg_box = QMessageBox.information(self, "wrong", "wrong password")
            # msg_box.show()







        print(name+password+re_password+tel+mail)


    def clear(self):
        
        print('清除')




# 批量导入
class InfoImport(QMainWindow, infoimport.Ui_MainWindow):
    global files2
    def __init__(self, parent=None):
        global files2
        files2=''
        super(InfoImport, self).__init__(parent)
        infoimport = self.setupUi(self)
        self.pushButton.clicked.connect(self.presee)
        self.pushButton_2.clicked.connect(self.confirm)
        self.toolButton.clicked.connect(self.getData)

    def presee(self):
        global files2
        try:
            workbook_ = load_workbook(filename=files2)  # 导入工作表
            sheetnames = workbook_.get_sheet_names()  # 获得表单名字
            sheet = workbook_.get_sheet_by_name(sheetnames[0])  # 从工作表中提取某一表单

            table1 = QTableWidget()
            table1.setColumnCount(12)
            horizontalHeader = []

            for col in range(1, 9):
                horizontalHeader.append(str(sheet.cell(row=1, column=col).value))

            table1.setHorizontalHeaderLabels(horizontalHeader)
            table1.setRowCount(50)
            if sheet.max_row>50:
                rr=50
            else:
                rr=sheet.max_row+1
            for row in range(2,rr):
                for col in range(1, 9):
                    table1.setItem(row-3, col-1, QTableWidgetItem(str(sheet.cell(row=row, column=col).value)))

            self.scrollArea.setWidget(table1)
            print("preview")
        except:
            print('wrong')
            msg_box = QMessageBox.critical(self, "wrong", "File not selected", QMessageBox.Yes)

    def confirm(self):
        global files2
        try:
            location=files2
            data = xlrd.open_workbook(location)
            table_one = data.sheet_by_index(0)  # 根据sheet索引获取sheet1的内容
            # table_two = data.sheet_by_index(1)                   # 根据sheet索引获取sheet2的内容


            db = pymysql.connect(host="localhost", user="root", passwd="123", db="wjy1", port=3306, use_unicode=True,
                                 charset='utf8')

            # for site in sites:
            # 遍历sheet1
            # for nrows_one in range(1, int(table_one.nrows)): # 读全部
            for nrows_one in range(2, table_one.nrows):  # 读前38行     40 就出错

                #        if table_one.cell_value(nrows_one, 0) == site:

                Publication_Date = table_one.cell_value(nrows_one, 3)  # 日期
                date = datetime(*xldate_as_tuple(Publication_Date, 0))
                Publication_Date = date.strftime('%Y/%m/%d')  #
                Id = int(table_one.cell_value(nrows_one, 0))  # id
                Jurisdiction = str(table_one.cell_value(nrows_one, 1))  # 国家
                Publication_Number = str(table_one.cell_value(nrows_one, 2))  # 专利号
                # Publication_Date = str(table_one.cell_value(nrows_one, 3))        #
                Publication_Year = int(table_one.cell_value(nrows_one, 4))  # 年
                Title = str(table_one.cell_value(nrows_one, 5))  # 标题
                Applicants = str(table_one.cell_value(nrows_one, 6))  # 申请人
                Inventors = str(table_one.cell_value(nrows_one, 7))  # 发明人


                #            break


                # 将数据存入数据库
                #    sql = "insert into patent_data(Id, Jurisdiction, Publication_Number, Publication_Date, Publication_Year, Title) " \
                #         "values (%s, %s, %s, %s, %s, %s)"

                sql = "insert into patent_data(Id, Jurisdiction, Publication_Number, Publication_Date, " \
                      "Publication_Year, Title, Applicants, Inventors) " \
                      "values (%s, %s, %s, %s, %s, %s, %s, %s)"


                    # 使用 cursor() 方法创建一个游标对象 cursor
                cursor = db.cursor()
                    #    cursor.execute(sql, (Id, Jurisdiction, Publication_Number, Publication_Date, Publication_Year, Title))
                cursor.execute(sql, (
                Id, Jurisdiction, Publication_Number, Publication_Date, Publication_Year, Title, Applicants, Inventors))


                db.commit()  # 事务提交
                msg_box = QMessageBox.information(self, "note", "success", QMessageBox.Yes)

        except:
            print('wrong')
            msg_box = QMessageBox.information(self, "note", "fail", QMessageBox.Yes)

        self.close()

        print("check")

    def getData(self):
        global files2
        file_name = QFileDialog.getOpenFileName(self, 'choose a file', '/')
        self.lineEdit.setText(file_name[0])
        files2=file_name[0]
        print(file_name)

# 个人信息页面
class Myinfo(QMainWindow, myinfo.Ui_MainWindow):
    def __init__(self, parent=None):
        super(Myinfo, self).__init__(parent)
        myinfo = self.setupUi(self)

        self.pushButton_2.clicked.connect(self.confirm)
        self.pushButton_3.clicked.connect(self.clear)



        self.timer = QTimer(self)  # 初始化一个定时器
        self.timer.timeout.connect(self.operate)  # 计时结束调用operate()方法
        self.timer.start(20)  # 设置计时间隔并启动



    def operate(self):
        f=open('cookies.txt','r')
        s=eval(f.read())
        f.close()
        if s['UserName']!=0:
            self.Applicants.setText(str(s['Tel']))
            self.Applicants_2.setText(str(s['Email']))
            self.timer.stop()


    # 添加一个清除按钮
    def clear(self):
        try:
            self.PublicationNumber.setText("")
            self.PublicationNumber_2.setText("")
            self.Applicants.setText("")
            self.Applicants_2.setText("")
            print("clear")
        except:
            print("erro")

    def confirm(self):
        f = open('cookies.txt', 'r')
        s = eval(f.read())
        f.close()
        repwd=self.PublicationNumber.text()
        pwd=self.PublicationNumber_2.text()
        tel=self.Applicants.text()
        mail=self.Applicants_2.text()
        print(pwd,repwd,tel,mail)
        sql = 'UPDATE userinfo SET'
        k=0
        pp=[]
        if pwd:
            if pwd!=repwd:
                print('wrong')
                return
            else:
                sql+=' Passwd = %s'
                k+=1
            pp.append(pwd)
        if tel:
            if k:
                sql+=', Tel = %s'
            else:
                sql+=' Tel = %s'
                k+=1
            pp.append(tel)
        if mail:
            if k:
                sql+=', Email = %s'
            else:
                sql+=' Email = %s'
                k+=1
            pp.append(mail)
        pp.append(str(s['UserName']))
        if k:
            sql+=' where UserName=%s'
            print(sql,pp)
            cus1 = conn.cursor()
            cus1.execute(sql,pp)
            cus1.close()
            conn.commit()




        print("confirm")


# 专利查询界面
class Infoquery(QMainWindow, infoquery.Ui_MainWindow):
    def __init__(self, parent=None):
        super(Infoquery, self).__init__(parent)
        infoquer = self.setupUi(self)
        self.infomanager.clicked.connect(self.manager)
        self.pushButton_2.clicked.connect(self.query)
        # self.pushButton_3.clicked.connect(self.pre)
        # self.pushButton_4.clicked.connect(self.next)

        self.infomanager.clicked.connect(self.manager)
        self.geneinfo.clicked.connect(self.manager)
        self.genequery.clicked.connect(self.manager)
        self.usermanager.clicked.connect(self.close)

        # self.pushButton_0.clicked.connect(self.info)   # 个人信息
        self.pushButton_9.clicked.connect(self.clear)   # 清除按钮
        self.timer = QTimer(self)  # 初始化一个定时器
        self.timer.timeout.connect(self.operate)  # 计时结束调用operate()方法
        self.timer.start(20)  # 设置计时间隔并启动



    # 当前用户0
    def operate(self):
        f=open('cookies.txt','r')
        x=eval(f.read())['UserName']
        if x!=0:
            self.label_0.setText(x)
            self.timer.stop()

    # 添加一个清除按钮
    def clear(self):
        try:
            self.ID.setText("")
            self.PublicationNumber.setText("")
            self.Jurisdiction_2.setCurrentIndex(0)
            # self.PublicationData.setText("")
            self.PublicationYear.setText("")
            self.Title.setText("")
            self.Applicants.setText("")
            self.lineEdit_6.setText("")
            print("clear")
        except:
            print("erro")
    # 个人信息按钮
    # def info(self):
    #     try:
    #         self.ID.setText("")
    #         self.PublicationNumber.setText("")
    #         self.Jurisdiction_2.setCurrentIndex(0)
    #         # self.PublicationData.setText("")
    #         self.PublicationYear.setText("")
    #         self.Title.setText("")
    #         self.Applicants.setText("")
    #         self.lineEdit_6.setText("")
    #         print("clear")
    #     except:
    #         print("erro")


    def manager(self):
        self.close()

    def query(self):
        ID = self.ID.text()
        patent_number = self.PublicationNumber.text()
        patent_name = self.Title.text()
        patent_firm = self.Applicants.text()
        patent_inventor = self.lineEdit_6.text()
        patent_date = self.PublicationDate.text()
        publication_year = self.PublicationYear.text()

        print(ID + patent_number + patent_name + patent_firm + patent_inventor + patent_date + publication_year)

        Jurisdiction = self.Jurisdiction_2.currentText()

        content1 = {'Id': False, 'Jurisdiction': False, 'Publication_Number': False, 'Publication_Date': False,
                    'Publication_Year': False, 'Title': False, 'Applicants': False, 'Inventors': False}
        content = (
        ID, Jurisdiction, patent_number, patent_date, publication_year, patent_name, patent_firm, patent_inventor)
        try:
            x = 0

            for j in content1:    # 判断管辖权为空格就不处理
                if content[x]!=' ':
                    content1[j] = content[x]
                x += 1

            sql = 'select * FROM patent_data WHERE'
            ks = 0
            pp=[]
            print(content)
            for j in content1:

                if content1[j]:
                    # if j=='Publication_Date' and content1[j]=='01/01/2000' :
                    if j=='Publication_Date' and content1[j]=='2000/1/1' :
                        continue
                    if ks > 0:
                        sql = sql + ' and'
                    if j=='Title' or j=='Applicants' or j=='Inventors':
                        sql += ' ' + str(j) + ' like %s'                        # 模糊查询改成like
                        pp.append('%'+str(content1[j])+'%')
                    else:

                        sql += ' ' + str(j) + '=%s'
                        pp.append(str(content1[j]))

                    ks += 1



            print(sql, pp)
            cus1 = conn.cursor()
            cus1.execute(sql, pp)

            result = cus1.fetchall()
            print(result)
            conn.commit()
            cus1.close()



            table = QTableWidget()
            table.setColumnCount(8)
            table.setColumnWidth(0, 90)
            table.setColumnWidth(1, 50)
            table.setColumnWidth(2, 100)
            table.setColumnWidth(3, 50)
            table.setColumnWidth(4, 50)
            table.setColumnWidth(5, 100)
            table.setColumnWidth(6, 100)
            table.setColumnWidth(7, 100)

            rows = len(result)
            table.setRowCount(rows)
            if rows>0:
                for i in range(rows):
                    k = 0
                    for j in result[i]:
                        table.setItem(i, k, QTableWidgetItem(str(result[i][j])))
                        k += 1
            horizontalHeader = ['Id', 'Jurisdiction ', 'patent number', 'date of publication', 'year of publication', 'invention name', 'applicant', 'inventor']
            table.setHorizontalHeaderLabels(horizontalHeader)
            self.scrollArea.setWidget(table)
        except:
            print('w')











        print("check")

    def next(self):
        print("the next one")

    def pre(self):
        print("the lase one")




def loginScu():
    f = open('cookies.txt', 'r')
    s=eval(f.read())
    if int(s['Type'])>0:
        genequery_gobal.show()
        loginWindowgobal.close()

def root():
    f = open('cookies.txt', 'r')
    s = eval(f.read())
    if int(s['Type'])>1:
        infoWindowgobal.show()

    else:
        infoquerygobal.show()



# 基因信息查询
class GeneInfo(QMainWindow, geneinfo.Ui_MainWindow):
    global gop
    gop=''
    def __init__(self, parent=None):
        gop=''
        super(GeneInfo, self).__init__(parent)
        infoimport = self.setupUi(self)
        # self.infomanager.clicked.connect(self.close)
        self.genequery.clicked.connect(self.close)
        # self.select.clicked.connect(self.close)
        self.usermanager.clicked.connect(self.close)

        self.pushButton_6.clicked.connect(self.add)
        self.pushButton.clicked.connect(self.modify)
        self.pushButton_5.clicked.connect(self.delet)
        # self.pushButton_3.clicked.connect(self.pre)
        # self.pushButton_4.clicked.connect(self.next)
        self.pushButton_2.clicked.connect(self.confirm)
        self.update1()
        self.pushButton_9.clicked.connect(self.clear) 

        self.timer = QTimer(self)  # 初始化一个定时器
        self.timer.timeout.connect(self.operate)  # 计时结束调用operate()方法
        self.timer.start(20)  # 设置计时间隔并启动

    # 当前用户
    def operate(self):
        f=open('cookies.txt','r')
        x=eval(f.read())['UserName']
        if x!=0:
            self.label_0.setText(x)
            self.timer.stop()

    # 添加一个清除按钮 1

    def clear(self):
        try:
            self.ID.setText("")
            self.PublicationNumber.setText("")
            self.Title.setText("")
            self.textEdit.setText("")
            # self.radioButton.Checked(False)

            _translate = QtCore.QCoreApplication.translate
            self.radioButton_2.close()
            self.radioButton.close()
            self.radioButton_3.close()

            self.radioButton = QtWidgets.QRadioButton(self.groupBox)
            self.radioButton.setGeometry(QtCore.QRect(0, 30, 100, 20))
            self.radioButton.setObjectName("radioButton")
            self.radioButton_2 = QtWidgets.QRadioButton(self.groupBox)
            self.radioButton_2.setGeometry(QtCore.QRect(80, 30, 100, 20))
            self.radioButton_2.setObjectName("radioButton_2")
            self.radioButton_3 = QtWidgets.QRadioButton(self.groupBox)
            self.radioButton_3.setGeometry(QtCore.QRect(170, 30, 100, 20))
            self.radioButton_3.setObjectName("radioButton_3")

            self.radioButton.setText(_translate("MainWindow", "Protein"))
            self.radioButton_2.setText(_translate("MainWindow", "Nucleotide"))
            self.radioButton_3.setText(_translate("MainWindow", "RNA"))

            self.radioButton.show()
            self.radioButton_2.show()
            self.radioButton_3.show()


            print ("clear")
        except:
            print ("erro")



    def update1(self):

        table = QTableWidget()
        table.setColumnCount(5)
        table.setColumnWidth(0, 50)
        table.setColumnWidth(1, 80)
        table.setColumnWidth(2, 100)
        table.setColumnWidth(3, 50)
        table.setColumnWidth(4, 100)

        sql = 'select * from fastas'
        cus = conn.cursor()
        cus.execute(sql)
        content = cus.fetchall()
        rows = len(content)
        table.setRowCount(rows)
        if rows>0:
            for i in range(rows):
                k = 0
                for j in content[i]:
                    if j!='seqContent':
                        table.setItem(i, k, QTableWidgetItem(str(content[i][j])))
                        k += 1
        horizontalHeader = ['Id', 'Patent number ', 'type', 'number of sequences', 'address']
        table.setHorizontalHeaderLabels(horizontalHeader)
        self.scrollArea.setWidget(table)


        return table





    def add(self):

        global gop
        gop='add'


        print("add")

    def modify(self):
        global gop
        gop = 'change'
        print("modify")

    def delet(self):
        global gop
        gop = 'del'
        print("delete")

    def pre(self):
        print("the lase one")

    def next(self):
        print("the next one")

    def confirm(self):
        global gop
        ID = self.ID.text()
        patent_number = self.PublicationNumber.text()
        patent_name = self.Title.text()
        sqeue = self.textEdit.toPlainText()
        seqType = ''
        if self.radioButton.isChecked():
            seqType = 'peptides'
        elif self.radioButton_2.isChecked():
            seqType = 'nucleotides'
        elif self.radioButton_3.isChecked():
            seqType = 'RNAs'
        else:
            seqType=False


        content1={'ID':False,'patentNum':False,'seqType':False,'seqNum':False,'seqContent':False,'location':False}
        content=[patent_number,seqType,patent_name,sqeue,'/']

        content1['ID']=ID
        try:
            x=-1
            for j in content1:
                if x==-1:
                    x+=1
                    continue
                content1[j] = content[x]
                x += 1


            if gop=='add':
                sql = 'INSERT INTO fastas (patentNum,seqType,seqNum,seqContent,location) VALUES (%s,%s,%s,%s,%s)'
                cus1 = conn.cursor()
                cus1.execute(sql, content)
                print(sql,content)
                conn.commit()
                cus1.close()
                self.update1()
                gop=''
            if gop=='del':
                pp = []
                sql = 'DELETE FROM fastas WHERE ID = %s'                 # 基因序列删除，只看id
                # ks = 0
                # for j in content1:
                #     if content1[j]:
                #         if ks > 0:
                #             sql = sql + ' and'
                #         sql += ' ' + str(j) + '=%s'
                #         pp.append(content1[j])
                #         ks += 1

                print(sql, [content1['ID']])
                cus1 = conn.cursor()
                cus1.execute(sql, pp)
                conn.commit()
                cus1.close()
                gop = ''
                self.update1()
            if gop=='change':
                sql = 'UPDATE fastas SET'
                ks = 0
                pp = []
                for j in content1:

                    if content1[j] and j != 'ID':
                        if ks > 0:
                            sql = sql + ','
                        sql += ' ' + str(j) + '=%s'
                        pp.append(content1[j])
                        ks += 1
                sql += ' where id=%s'
                print(sql, pp)
                pp.append(ID)
                cus1 = conn.cursor()
                cus1.execute(sql, pp)
                conn.commit()
                cus1.close()
                gop = ''
                self.update1()
        except:
            print('w')





        self.update1()
        print('id',ID ,'patent_number', patent_number , 'patent_name',patent_name , 'sqeue',sqeue)
        # patent_firm = self.Applicants.text()
        # patent_inventor = self.lineEdit_6.text()
        # patent_date = self.PublicationDate.text()
        # publication_year = self.PublicationYear.text()
        # print(ID+patent_number+patent_name+patent_firm+patent_inventor+patent_date+publication_year)
        # print("确认")








    def select1(self):
        self.close()





        print("search")


# 基因信息管理
class Genequery(QMainWindow, genequery.Ui_MainWindow):
    def __init__(self, parent=None):
        super(Genequery, self).__init__(parent)
        infoimport = self.setupUi(self)
        # self.infomanager.clicked.connect(self.close)
        self.geneinfo.clicked.connect(self.close)
        # self.select.clicked.connect(self.close)
        self.usermanager.clicked.connect(self.close)

        self.pushButton_2.clicked.connect(self.confirm)
        self.pushButton_9.clicked.connect(self.clear)

        self.timer = QTimer(self)  # 初始化一个定时器
        self.timer.timeout.connect(self.operate)  # 计时结束调用operate()方法
        self.timer.start(20)  # 设置计时间隔并启动

    # 当前用户
    def operate(self):
        f = open('cookies.txt', 'r')
        x = eval(f.read())['UserName']
        if x != 0:
            self.label_0.setText(x)
            self.timer.stop()

        # 添加一个清除按钮 2
    def clear(self):
        try:
            self.ID.setText("")
            self.PublicationNumber.setText("")
            self.Title.setText("")
            self.textEdit.setText("")

            _translate = QtCore.QCoreApplication.translate
            self.radioButton_2.close()
            self.radioButton.close()
            self.radioButton_3.close()

            self.radioButton = QtWidgets.QRadioButton(self.groupBox)
            self.radioButton.setGeometry(QtCore.QRect(0, 30, 100, 20))
            self.radioButton.setObjectName("radioButton")
            self.radioButton_2 = QtWidgets.QRadioButton(self.groupBox)
            self.radioButton_2.setGeometry(QtCore.QRect(80, 30, 100, 20))
            self.radioButton_2.setObjectName("radioButton_2")
            self.radioButton_3 = QtWidgets.QRadioButton(self.groupBox)
            self.radioButton_3.setGeometry(QtCore.QRect(170, 30, 100, 20))
            self.radioButton_3.setObjectName("radioButton_3")

            self.radioButton.setText(_translate("MainWindow", "Protein"))
            self.radioButton_2.setText(_translate("MainWindow", "Nucleotide"))
            self.radioButton_3.setText(_translate("MainWindow", "RNA"))

            self.radioButton.show()
            self.radioButton_2.show()
            self.radioButton_3.show()

            print ("clear")
        except:
            print ("erro")

    def confirm(self):
        global gop
        ID = self.ID.text()
        patent_number = self.PublicationNumber.text()
        patent_name = self.Title.text()
        sqeue = self.textEdit.toPlainText()
        seqType = ''
        if self.radioButton.isChecked():
            seqType = 'peptides'
        elif self.radioButton_2.isChecked():
            seqType = 'nucleotides'
        elif self.radioButton_3.isChecked():
            seqType = 'RNAs'
        else:
            seqType = False

        content1 = {'ID': False, 'patentNum': False, 'seqType': False, 'seqNum': False, 'seqContent': False}
        content = [ID, patent_number, seqType, patent_name, sqeue]
        content1['ID'] = ID
        try:
            x = 0
            for j in content1:
                if content[x]:
                    content1[j] = content[x]
                x += 1

            sql = 'select * FROM fastas WHERE'
            ks = 0
            pp = []
            for j in content1:

                if content1[j]:
                    if ks > 0:
                        sql = sql + ' and'
                    sql += ' ' + str(j) + '=%s'
                    pp.append(content1[j])
                    ks += 1

            print(sql, pp)
            cus1 = conn.cursor()
            cus1.execute(sql, pp)

            result = cus1.fetchall()
            print(result)
            conn.commit()
            cus1.close()

            table = QTableWidget()
            table.setColumnCount(5)
            table.setColumnWidth(0, 50)
            table.setColumnWidth(1, 80)
            table.setColumnWidth(2, 100)
            table.setColumnWidth(3, 50)
            table.setColumnWidth(4, 200)


            rows = len(result)
            table.setRowCount(rows)
            if rows > 0:
                for i in range(rows):
                    k = 0
                    for j in result[i]:
                        if j != 'seqContent':
                            table.setItem(i, k, QTableWidgetItem(str(result[i][j])))
                            k += 1
            horizontalHeader = ['Id', 'Patent number ', 'type', 'number of sequences', 'address']
            table.setHorizontalHeaderLabels(horizontalHeader)
            self.scrollArea.setWidget(table)
        except:
            print('w')








# 基因批量导入
class Geneimport(QMainWindow, geneimport.Ui_MainWindow):
    global files
    def __init__(self, parent=None):
        global files
        files=[]
        super(Geneimport, self).__init__(parent)
        infoimport = self.setupUi(self)

        self.toolButton.clicked.connect(self.getData)

        self.pushButton.clicked.connect(self.foresee)
        self.pushButton_2.clicked.connect(self.conform)


    def foresee(self):
        global files
        if files:

            f = open(files[0], 'r')
            content=f.read()

            self.textbox.setText(content)


            print("123")

    def getData(self):
        global files
        file_name = QFileDialog.getOpenFileName(self, 'choose picture', '/')
        self.lineEdit.setText(file_name[0])
        files=[file_name[0]]

    def conform(self):
        global files
        try:
            if files:
                for name in files:
                    # 这里先要看后缀是不是fasta，不是的文件跳过
                    a = name.split('.')
                    if a[1] != 'fasta':
                        continue

                    # 下面是执行数据库的插入语句，格式是标准格式。这里用with好像比较好，不太懂哪儿好

                    with conn.cursor() as cursor:
                            # 先把要执行的语句写成string格式存在sql变量下，其中%s代表要用元祖赋值的值
                        sql = 'INSERT INTO fastas (patentNum,seqType,seqNum,seqContent,location) VALUES (%s,%s,%s,%s,%s)'
                        z=read(name)
                        print(z)
                            # excute是执行
                        cursor.execute(sql, z)
                        # 提交
                    conn.commit()

                    print('success')
                    msg_box = QMessageBox.information(self, "note", "success", QMessageBox.Yes)

                    self.close()
        except:
            return
            msg_box = QMessageBox.information(self, "note", "fail", QMessageBox.Yes)


# 用户管理
class Usermanager(QMainWindow, usermanager.Ui_MainWindow):
    def __init__(self, parent=None):
        global uop
        uop=''
        super(Usermanager, self).__init__(parent)
        infoimport = self.setupUi(self)
        # self.infomanager.clicked.connect(self.close)
        self.geneinfo.clicked.connect(self.close)
        # self.select.clicked.connect(self.close)
        self.genequery.clicked.connect(self.close)
        self.update1()

        self.pushButton_5.clicked.connect(self.del1)
        self.pushButton.clicked.connect(self.change)
        self.pushButton_2.clicked.connect(self.conform)
        self.pushButton_9.clicked.connect(self.clear)

        self.timer = QTimer(self)  # 初始化一个定时器
        self.timer.timeout.connect(self.operate)  # 计时结束调用operate()方法
        self.timer.start(20)  # 设置计时间隔并启动

        # 当前用户
    def operate(self):
        f = open('cookies.txt', 'r')
        x = eval(f.read())['UserName']
        if x != 0:
            self.label_0.setText(x)
            self.timer.stop()
    # 添加一个清除按钮 3
    def clear(self):
        try:
            self.ID.setText("")
            self.PublicationNumber.setText("")
            self.Title.setText("")
            self.Title_2.setText("")
            print ("clear")
        except:
            print ("erro")

    def update1(self):

        table = QTableWidget()
        table.setColumnCount(6)
        table.setColumnWidth(0, 50)
        table.setColumnWidth(1, 70)
        table.setColumnWidth(2, 80)
        table.setColumnWidth(3, 130)
        table.setColumnWidth(4, 130)
        table.setColumnWidth(5, 150)

        sql = 'select * from (userinfo)'
        cus = conn.cursor()
        cus.execute(sql)
        content = cus.fetchall()
        print(content)
        rows = len(content)
        table.setRowCount(rows)
        cus.close()
        if rows>0:
            for i in range(rows):
                k = 0
                for j in content[i]:

                    if j!='Passwd' and j!='isdelete':
                        if j=='Type' and content[i][j]==1:
                            ccc='普通用户'
                        elif j=='Type' and content[i][j]==2:
                            ccc='管理员'

                        if j=='Sex' and content[i][j]==1:
                            ccc='男'
                        elif j=='Sex' and content[i][j]==2:
                            ccc='女'
                        else:
                            ccc=content[i][j]
                        table.setItem(i, k, QTableWidgetItem(str(ccc)))
                        k += 1
        horizontalHeader = ['Id','用户名', '性别 1男 2女', 'Email', 'Tel', '级别 1用户2管理员']
        table.setHorizontalHeaderLabels(horizontalHeader)
        self.scrollArea.setWidget(table)


    def del1(self):
        global uop
        uop='del'


    def change(self):
        global uop
        uop='change'

    def conform(self):
        global uop
        ID=self.ID.text()
        usrname=self.PublicationNumber.text()
        email=self.Title.text()
        tel=self.Title_2.text()
        type=0
        if self.radioButton_5.isChecked():
            type=1
        elif self.radioButton_6.isChecked():
            type=2
        sex=0
        if self.radioButton.isChecked():
            sex=1
        elif self.radioButton_2.isChecked():
            sex=2

        content1=[ID,usrname,sex,email,tel,type]




        content={'id': False, 'UserName': False, 'Sex': False, 'Email': False, 'Tel': False, 'Type': False, }
        k=0
        pp=[]
        for j in content:
            if content1[k]:
                if j!='id':
                    pp.append(content1[k])
                content[j]=content1[k]
            k+=1


        if uop=='del':
            sql = 'DELETE FROM userinfo WHERE ID = %s'
            cus = conn.cursor()
            print(sql,ID)
            cus.execute(sql,(ID))
            cus.close()
            conn.commit()
            self.update1()
            uop=''
            msg_box = QMessageBox.information(self, "提示", "删除成功", QMessageBox.Yes)

        elif uop=='change':
            sql = 'UPDATE userinfo SET'
            ks=0
            for j in content:

                if content[j] and j!='id':
                    if ks > 0:
                        sql = sql + ' ,'
                    sql += ' ' + str(j) + '=%s'

                    ks += 1
            sql+=' where id=%s'
            pp.append(ID)
            cus = conn.cursor()
            print(sql, pp)
            cus.execute(sql, pp)
            cus.close()
            conn.commit()
            uop=''
            msg_box = QMessageBox.information(self, "提示", "修改成功", QMessageBox.Yes)

        self.update1()






















# 权限设置

def root2():
    f = open('cookies.txt', 'r')
    s = eval(f.read())
    if int(s['Type']) > 1:
        geneinfo_gobal.show()
    else:
        infoquery.show()


def root3():
    f = open('cookies.txt', 'r')
    s = eval(f.read())
    if int(s['Type']) > 1:
        usermanager_gobal.show()
    else:
        infoquerygobal.show()

def root4():
    f = open('cookies.txt', 'r')
    s = eval(f.read())
    if int(s['Type']) > 1:
        usermanager_gobal.show()
    else:
        geneinfo_gobal.show()

def root5():
    f = open('cookies.txt', 'r')
    s = eval(f.read())
    if int(s['Type']) > 1:
        usermanager_gobal.show()
    else:
        genequery_gobal.show()

def root6():
    f = open('cookies.txt', 'r')
    s = eval(f.read())
    if int(s['Type']) > 1:
        infoWindowgobal.show()

    else:
        genequery_gobal.show()


def root7():
    f = open('cookies.txt', 'r')
    s = eval(f.read())
    if int(s['Type']) > 1:
        infoWindowgobal.show()

    else:
        geneinfo_gobal.show()

def root8():
    f = open('cookies.txt', 'r')
    s = eval(f.read())
    if int(s['Type']) > 1:
        geneinfo_gobal.show()
    else:
        genequery_gobal.show()


# 法律查询
class Lawquery(QMainWindow, lawquery.Ui_MainWindow):
    def __init__(self, parent=None):
        super(Lawquery, self).__init__(parent)
        infoimport = self.setupUi(self)
        self.pushButton.clicked.connect(self.confirm)
        self.pushButton_2.clicked.connect(self.add)
        self.pushButton_3.clicked.connect(self.modify)
        self.pushButton_4.clicked.connect(self.delete)

        self.timer = QTimer(self)  # 初始化一个定时器
        self.timer.timeout.connect(self.operate)  # 计时结束调用operate()方法
        self.timer.start(20)  # 设置计时间隔并启动

    #法律增加
    def add(self):
        try:

            ID = self.ID.text()
            law_number = self.PublicationNumber.text()
            law_Abstract = self.textEdit_1.toPlainText()
            law_TechnicalField = self.textEdit.toPlainText()
            law_Background = self.textEdit_2.toPlainText()
            law_Claim = self.textEdit_3.toPlainText()

            print(ID + law_number + law_Abstract + law_TechnicalField + law_Background + law_Claim)

            content1 = {'ID': False, 'patentNum': False, 'Abstract': False, 'TechnicalField': False,
                        'Background': False, 'Claim': False}
            content = (ID, law_number, law_Abstract, law_TechnicalField, law_Background, law_Claim)

            x = 0
            try:
                for j in content1:
                    content1[j] = content[x]
                    x += 1
            except:
                print()

            sql = "insert into law(Id, patentNum, Abstract, TechnicalField, Background, Claim) " \
                  "values (%s, %s, %s, %s, %s, %s)"

            cus1 = conn.cursor()
            cus1.execute(sql, content)
            conn.commit()
            cus1.close()
            msg_box = QMessageBox.information(self, "提示", "增加成功", QMessageBox.Yes)
        except:
            print('wrong')
            msg_box = QMessageBox.warning(self, "警告", "增加失败", QMessageBox.Cancel)
        # self.update1()
        print("add")

    # 法律修改
    def modify(self):

        ID = self.ID.text()
        law_number = self.PublicationNumber.text()
        law_Abstract = self.textEdit_1.toPlainText()
        law_TechnicalField = self.textEdit.toPlainText()
        law_Background = self.textEdit_2.toPlainText()
        law_Claim = self.textEdit_3.toPlainText()

        print(ID + law_number + law_Abstract + law_TechnicalField + law_Background + law_Claim)

        content1 = {'patentNum': False, 'Abstract': False, 'TechnicalField': False,
                'Background': False, 'Claim': False}
        content = (law_number, law_Abstract, law_TechnicalField, law_Background, law_Claim)

        x = 0
        try:
            for j in content1:
                content1[j] = content[x]
                x += 1
        except:
            print()




        sql='UPDATE law SET'
        ks=0
        pp=[]

        try:
            for j in content1:

                if content1[j] and j != 'id':

                    if ks>0:
                        sql=sql+','
                    sql+=' '+str(j)+'=%s'
                    pp.append(content1[j])
                    ks+=1
            sql+=' where id=%s'

            print(sql, pp)

            pp.append(ID)
            cus1 = conn.cursor()
            cus1.execute(sql, pp)
            conn.commit()
            cus1.close()
            msg_box = QMessageBox.information(self, "提示", "修改成功", QMessageBox.Yes)

        except:
            print('wrong')
            msg_box = QMessageBox.warning(self, "警告", "修改失败", QMessageBox.Cancel)

        print("modify")

    # 法律删除
    def delete(self):

        ID = self.ID.text()
        law_number = self.PublicationNumber.text()
        law_Abstract = self.textEdit_1.toPlainText()
        law_TechnicalField = self.textEdit.toPlainText()
        law_Background = self.textEdit_2.toPlainText()
        law_Claim = self.textEdit_3.toPlainText()

        print(ID + law_number + law_Abstract + law_TechnicalField + law_Background + law_Claim)

        content1 = {'patentNum': False, 'Abstract': False, 'TechnicalField': False,
                    'Background': False, 'Claim': False}
        content = (law_number, law_Abstract, law_TechnicalField, law_Background, law_Claim)

        x = 0
        try:
            for j in content1:
                content1[j] = content[x]
                x += 1
        except:
            print()

        pp = []
        sql = 'DELETE FROM law WHERE'
        ks = 0
        try:
            for j in content1:
                # if j == 'Publication_Date' and content1[j] == '2000/1/1':
                #     continue
                if content1[j]:
                    if ks > 0:
                        sql = sql + ' and'
                    sql += ' ' + str(j) + '=%s'
                    pp.append(content1[j])
                    ks += 1

        except:
            print('wrong')

        print(sql, pp)
        try:

            cus1 = conn.cursor()
            cus1.execute(sql, pp)
            conn.commit()
            cus1.close()
            msg_box = QMessageBox.information(self, "提示", "删除成功", QMessageBox.Yes)
        except:
            print('wrong')
            msg_box = QMessageBox.critical(self, "错误", "删除失败", QMessageBox.Cancel)
        # op = ''
        # self.update1()

    print("delete")



    # 当前用户
    def operate(self):
        f = open('cookies.txt', 'r')
        x = eval(f.read())['UserName']
        if x != 0:
            self.label_0.setText(x)
            self.timer.stop()

    # # 查询按钮
    def confirm(self):
        import pymysql.cursors
        import matplotlib.pyplot as plt
        try:
            # Num 是专利号，Id是id先设置为不可能查询到的两个值
            Num = '0'
            ID = '0'

            # 下面两个是读取的用户输入的id和专利号
            enterId = self.ID.text()
            enterNum = self.PublicationNumber.text()

            print(enterId)

            if enterId:
                ID = enterId
            if enterNum:
                Num = enterNum

            sql = 'select * from law where ID=%s or patentNum=%s'

            cus1 = conn.cursor()
            cus1.execute(sql, (ID, Num))
            result = cus1.fetchall()
            print(result[0]['TechnicalField'])


            self.textEdit_1.setText(result[0]['Abstract'])
            self.textEdit.setText(result[0]['TechnicalField'])
            self.textEdit_2.setText(result[0]['Background'])
            self.textEdit_3.setText(result[0]['Claim'])

            # reslut是字典，result['键值']就会得到对应的内容
        except:
            msg_box = QMessageBox.critical(self, "Error ", "The related information does not exist", QMessageBox.Cancel)




# 专利统计
class Stastics(QMainWindow, stastics.Ui_MainWindow):
    def __init__(self, parent=None):
        super(Stastics, self).__init__(parent)
        infoimport = self.setupUi(self)
        self.pushButton_3.clicked.connect(self.clear)
        self.pushButton_2.clicked.connect(self.bing)
        self.pushButton.clicked.connect(self.zhu)
        self.label_20.setPixmap(QtGui.QPixmap("c.png"))





    def clear(self):
        print("clear")
        self.label_20.setPixmap(QtGui.QPixmap("c.png"))
        


    def save2(self):
        plt.cla
        matplotlib.use('Agg')
        start = self.lineEdit.text()
        end = self.lineEdit_2.text()

        yearStart = int(start)
        yearEnd = int(end)
        result = 1
        try:
            with conn.cursor() as cursor:
                # 先把要执行的语句写成string格式存在sql变量下，其中%s代表要用元祖赋值的值
                sql = 'select * from patent_data where Publication_Year>=%s and Publication_Year<=%s;'
                # excute就是执行了
                cursor.execute(sql, (yearStart, yearEnd))
                result = cursor.fetchall()
                conn.commit()


        except:
            result = False
            print('search wrong')

        year = {}
        if result:
            for a in result:
                if a['Publication_Year'] in year:
                    year[a['Publication_Year']] += 1
                else:
                    year[a['Publication_Year']] = 1
            x = sorted(year, reverse=True)
            y = []

            for a in x:
                y.append(year[a])



            x = [str(x[i]) for i in range(len(x))]



            plt.pie(y, labels=x)


            savefig('b.png')
            plt.close()


    def bing(self):
        try:
            self.save2()
            self.label_20.setPixmap(QtGui.QPixmap("b.png"))
            print("pie chart")
        except:
            return

    def save(self):

        matplotlib.use('Agg')
        start = self.lineEdit.text()
        end = self.lineEdit_2.text()

        yearStart = int(start)
        yearEnd = int(end)
        result = 1
        try:
            with conn.cursor() as cursor:
                # 先把要执行的语句写成string格式存在sql变量下，其中%s代表要用元祖赋值的值
                sql = 'select * from patent_data where Publication_Year>=%s and Publication_Year<=%s;'
                # excute就是执行了
                cursor.execute(sql, (yearStart, yearEnd))
                result = cursor.fetchall()
                conn.commit()


        except:
            result = False
            print('search wrong')

        year = {}
        if result:
            for a in result:
                if a['Publication_Year'] in year:
                    year[a['Publication_Year']] += 1
                else:
                    year[a['Publication_Year']] = 1
            x = sorted(year, reverse=True)
            y = []


            for a in x:
                y.append(year[a])

            yearStart = int(yearStart)
            yearEnd = int(yearEnd)
            print(x,y)

            plt.xticks([i for i in range(yearEnd, yearStart - 1, -1)],
                       [str(i) for i in range(yearEnd, yearStart - 1, -1)])

            plt.bar(x, y, 0.8, color=['brown', 'orange', 'darkgreen', 'navy'])
            plt.xlabel('Publication_Year', color='black')

            plt.ylabel('amount', color='black')


            savefig('a.png')
            plt.close()



    def zhu(self):
        try:
            self.save()
            self.label_20.setPixmap(QtGui.QPixmap("a.png"))
        except:
            return

#法律导入
class Lawimport(QMainWindow,lawimport.Ui_MainWindow):
    def __init__(self, parent=None):
        super(Lawimport, self).__init__(parent)
        infoimport = self.setupUi(self)
        self.pushButton.clicked.connect(self.yulan)
        self.pushButton_2.clicked.connect(self.confirm)
        self.toolButton.clicked.connect(self.getData)

    def yulan(self):
        global files2
        try:
            workbook_ = load_workbook(filename=files2)  # 导入工作表
            sheetnames = workbook_.get_sheet_names()  # 获得表单名字
            sheet = workbook_.get_sheet_by_name(sheetnames[0])  # 从工作表中提取某一表单

            table1 = QTableWidget()
            table1.setColumnCount(6)
            horizontalHeader = []

            for col in range(1, 7):
                horizontalHeader.append(str(sheet.cell(row=1, column=col).value))

            table1.setHorizontalHeaderLabels(horizontalHeader)
            table1.setRowCount(6)
            if sheet.max_row > 50:
                rr = 50
            else:
                rr = sheet.max_row + 1
            for row in range(2, rr):
                for col in range(1, 7):
                    table1.setItem(row - 3, col - 1, QTableWidgetItem(str(sheet.cell(row=row, column=col).value)))

            self.scrollArea.setWidget(table1)
            print("preview")
        except:
            print('wrong')


    def confirm(self):
        global files2
        try:
            data = xlrd.open_workbook(files2)  # 读取excel表格

            # location = input("请输入地址: ")              # 在用户界面选择文档@@
            # data = xlrd.open_workbook(location)
            table_one = data.sheet_by_index(0)  # 根据sheet索引获取sheet1的内容

            db = pymysql.connect(host="localhost", user="root", passwd="123", db="wjy1", port=3306, use_unicode=True,
                                 charset='utf8')

            for nrows_one in range(1, int(table_one.nrows)):  # 读全部

                # Id = int(table_one.cell_value(nrows_one, 0))

                patentNum = str(table_one.cell_value(nrows_one, 1))
                Abstract = str(table_one.cell_value(nrows_one, 2))  #
                TechnicalField = str(table_one.cell_value(nrows_one, 3))  #
                Background = str(table_one.cell_value(nrows_one, 4))  #
                Claim = str(table_one.cell_value(nrows_one, 5))  #

                sql = "insert into law(patentNum, Abstract, TechnicalField, Background, Claim)" \
                      "values (%s, %s, %s, %s, %s)"

                try:
                    # 使用 cursor() 方法创建一个游标对象 cursor
                    cursor = db.cursor()
                    cursor.execute(sql, ((patentNum, Abstract, TechnicalField, Background, Claim)))
                except Exception as e:
                    # 发生错误时回滚
                    db.rollback()
                    print(str(e))
                else:
                    db.commit()  # 事务提交
                    print('事务处理成功')
                    msg_box = QMessageBox.information(self, "note", "success", QMessageBox.Yes)

            # 返回查询结果记录数
            cursor.execute("select * from law")
            new_id = cursor.rowcount
            print('目前数据库内共有', new_id, '条数据')
        except:
            print("Erro")
            msg_box = QMessageBox.information(self, "提示", "导入失败", QMessageBox.Yes)

    def getData(self):
        #获取文件路径
        global files2
        file_name = QFileDialog.getOpenFileName(self, '选择文件', '/')

        self.lineEdit.setText(file_name[0])
        files2 = file_name[0]
        print(file_name)

        # self.label_20.setPixmap(QtGui.QPixmap("c.png"))


if __name__ == '__main__':

    global infoquerygobal,loginWindowgobal,infoWindowgobal,geneinfo_gobal,geneinfo_gobal,genequery_gobal,geneimport_gobal,usermanager_gobal
    f=open('cookies.txt','w')
    f.write("{'id': 0, 'UserName': 0, 'Passwd':0, 'Sex': 0, 'Email': 0, 'Tel': 0, 'Type': 0}")
    f.close()
    app = QApplication( sys.argv )
    loginWindow = LoginWindow()
    loginWindow.show()
    infoimport = InfoImport()
    infoquery = Infoquery()
    geneinfo_ = GeneInfo()
    genequery_ = Genequery()
    geneimport_ = Geneimport()
    usermanager_ = Usermanager()
    infoWindow = Infomanager()
    lawimport_ = Lawimport()
    # lawimport_2 = Lawimport()
    myinfo = Myinfo()                           ###



    infoquerygobal=infoquery
    loginWindowgobal=loginWindow
    infoWindowgobal=infoWindow
    geneinfo_gobal=geneinfo_
    genequery_gobal=genequery_
    geneimport_gobal=geneimport_
    usermanager_gobal=usermanager_


    register = Register()
    loginWindow.pushButton.clicked.connect(loginWindow.if_Login)
    loginWindow.pushButton_1.clicked.connect(register.show)


    #loginWindow.pushButton.clicked.connect(infoWindow.show)
    loginWindow.pushButton.clicked.connect(loginScu)

    loginWindow.pushButton_1.clicked.connect(register.show)
    infoWindow.pushButton_7.clicked.connect(infoimport.show)
    infoWindow.select.clicked.connect(infoquery.show)
    infoquery.infomanager.clicked.connect(root)



    #=================
#    infoWindow.pushButton_7.clicked.connect(infoimport.show)
#    infoWindow.select.clicked.connect(infoquery.show)
    infoWindow.geneinfo.clicked.connect(geneinfo_.show)
    infoWindow.genequery.clicked.connect(genequery_.show)
    infoWindow.usermanager.clicked.connect(usermanager_.show)

#    infoquery.infomanager.clicked.connect(infoWindow.show)
    infoquery.geneinfo.clicked.connect(root2)
    infoquery.genequery.clicked.connect(genequery_.show)
    infoquery.usermanager.clicked.connect(root3)

    # geneinfo_.infomanager.clicked.connect(root7)
    # geneinfo_.select.clicked.connect(infoquery.show)
    geneinfo_.genequery.clicked.connect(genequery_.show)
    geneinfo_.pushButton_7.clicked.connect(geneimport_.show)
    geneinfo_.usermanager.clicked.connect(root4)

    # genequery_.infomanager.clicked.connect(root6)
    # genequery_.select.clicked.connect(infoquery.show)
    genequery_.geneinfo.clicked.connect(root8)
    genequery_.usermanager.clicked.connect(root5)

    # usermanager_.infomanager.clicked.connect(infoWindow.show)
    # usermanager_.select.clicked.connect(infoquery.show)
    usermanager_.geneinfo.clicked.connect(geneinfo_.show)
    usermanager_.genequery.clicked.connect(genequery_.show)

    # loginWindow.pushButton_1.clicked.connect(loginWindow.close)
    mainquery_ = Lawquery()
    mainquery_.pushButton_5.clicked.connect(lawimport_.show) # 点导入按钮 弹出新页面
    # mainquery_.pushButton_5.clicked.connect(lawimport_2.show)
    stastics_ = Stastics()
    # maptu_ = Maptu()

#####
    # 点个人信息按钮 弹出新页面
    maininfo_ = Myinfo()
    # maininfo_.pushButton_0.clicked.connect(myinfo_.show)
    infoquery.pushButton_0.clicked.connect(maininfo_.show)
    infoWindow.pushButton_0.clicked.connect(maininfo_.show)
    geneinfo_.pushButton_0.clicked.connect(maininfo_.show)
    genequery_.pushButton_0.clicked.connect(maininfo_.show)
    usermanager_.pushButton_0.clicked.connect(maininfo_.show)
    mainquery_.pushButton_0.clicked.connect(maininfo_.show)
#####



    infoWindow.mainquery.clicked.connect(mainquery_.show)
    infoWindow.statistic.clicked.connect(stastics_.show)
    #   infoWindow.patent.clicked.connect(maptu_.show)

    infoquery.mainquery.clicked.connect(mainquery_.show)
    infoquery.statistic.clicked.connect(stastics_.show)
    #    infoquery.patent.clicked.connect(maptu_.show)

    # geneinfo_.mainquery.clicked.connect(mainquery_.show)
    geneinfo_.statistic.clicked.connect(stastics_.show)
    #    geneinfo_.patent.clicked.connect(maptu_.show)

    # genequery_.mainquery.clicked.connect(mainquery_.show)
    genequery_.statistic.clicked.connect(stastics_.show)
    #    genequery_.patent.clicked.connect(maptu_.show)

#    usermanager_.mainquery.clicked.connect(mainquery_.show)
    usermanager_.statistic.clicked.connect(stastics_.show)
    #    usermanager_.patent.clicked.connect(maptu_.show)



    sys.exit(app.exec_())
