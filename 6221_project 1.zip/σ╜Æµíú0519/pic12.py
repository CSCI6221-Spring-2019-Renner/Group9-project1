#读取csv
import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
data = pd.read_csv('/Users/WJY/Desktop/转基因的数据们/rice1000_2.csv')
data.head()

data.shape

# choose_year1=input('请输入查询起始年份：')
# choose_year2=input('请输入查询终止年份：')

#choose_year3=data[data[u'Publication Year’]>choose_year1]    #想要能够按输入的年份查询，不知道怎么并列和导入参数
choose_year3=data


#计数
#count=data[u'Publication Year'].value_counts()
count=choose_year3[u'Publication Year'].value_counts()
#显示计数结果
print (count)

#图  https://jingyan.baidu.com/article/bad08e1e8d2e9809c851212b.html
#plt=count.plot(kind='bar').get_figure()
#plt=count.plot(kind='bar',stacked=True).get_figure()
plt=count.plot(kind='bar',stacked=True)

plt.set_ylabel('Amount')
plt.set_xlabel('Year')

fig = plt.get_figure()

#横向图
#plt=count.plot(kind='barh', rot=0).get_figure()
#保存图片
fig.savefig('/Users/WJY/Desktop/Gene Information/year.png')
#显示图片
fig.show()
