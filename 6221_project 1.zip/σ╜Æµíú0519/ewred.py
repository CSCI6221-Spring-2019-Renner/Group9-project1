a=[1,2,3]
print(a[-1:])