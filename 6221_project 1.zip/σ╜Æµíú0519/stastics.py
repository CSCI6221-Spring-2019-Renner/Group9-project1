# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file '/Users/luxx/Desktop/wjy/窗口/统计图-柱状图.ui'
#
# Created by: PyQt5 UI code generator 5.6
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets
import matplotlib
import pymysql
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.pyplot import savefig




class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(515, 600)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.centralwidget)
        self.verticalLayout.setObjectName("verticalLayout")
        self.tabWidget = QtWidgets.QTabWidget(self.centralwidget)
        self.tabWidget.setEnabled(True)
        self.tabWidget.setObjectName("tabWidget")
        self.tab1 = QtWidgets.QWidget()
        self.tab1.setObjectName("tab1")
        self.label_5 = QtWidgets.QLabel(self.tab1)
        self.label_5.setGeometry(QtCore.QRect(180, 0, 117, 19))
        self.label_5.setObjectName("label_5")

        self.frame = QtWidgets.QFrame(self.tab1)
        self.frame.setGeometry(QtCore.QRect(10, 30, 461, 477))
        self.frame.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        self.gridLayout = QtWidgets.QGridLayout(self.frame)
        self.gridLayout.setObjectName("gridLayout")
        self.lineEdit = QtWidgets.QLineEdit(self.frame)
        self.lineEdit.setObjectName("lineEdit")
        self.gridLayout.addWidget(self.lineEdit, 0, 1, 1, 1)
        self.label = QtWidgets.QLabel(self.frame)
        self.label.setObjectName("label")
        self.gridLayout.addWidget(self.label, 0, 0, 1, 1)
        self.pushButton = QtWidgets.QPushButton(self.frame)
        self.pushButton.setObjectName("pushButton")
        self.gridLayout.addWidget(self.pushButton, 2, 2, 1, 1)
        self.lineEdit_2 = QtWidgets.QLineEdit(self.frame)
        
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.gridLayout.addWidget(self.lineEdit_2, 1, 1, 1, 1)
        self.label_2 = QtWidgets.QLabel(self.frame)
        self.label_2.setObjectName("label_2")
        self.gridLayout.addWidget(self.label_2, 1, 0, 1, 1)

        self.label_20 = QtWidgets.QLabel(self.frame)
        self.label_20.setObjectName("label_20")
        self.label_20.setScaledContents(True)
        self.gridLayout.addWidget(self.label_20, 3, 0, 10, 5)

        self.pushButton_2 = QtWidgets.QPushButton(self.frame)
        self.pushButton_2.setObjectName("pushButton_2")
        self.gridLayout.addWidget(self.pushButton_2, 1, 2, 1, 1)
        self.pushButton_3 = QtWidgets.QPushButton(self.frame)
        self.pushButton_3.setObjectName("pushButton_3")
        self.gridLayout.addWidget(self.pushButton_3, 0, 2, 1, 1)





        self.tabWidget.addTab(self.tab1, "")
        self.tab2 = QtWidgets.QWidget()
        self.tab2.setObjectName("tab2")

        self.label_4 = QtWidgets.QLabel(self.tab2)
        self.label_4.setGeometry(QtCore.QRect(180, 10, 121, 16))
        self.label_4.setObjectName("label_4")
        # self.gridLayout_map = QtWidgets.QGridLayout(self.tab2)
        # self.gridLayout_map.setObjectName("gridLayout")

        self.savet()
        self.label_me = QtWidgets.QLabel(self.tab2)
        self.label_me.setScaledContents(True)
        self.label_me.setGeometry(QtCore.QRect(20, 30, 450, 450))
        self.label_me.setObjectName("label_me")
        self.label_me.setPixmap(QtGui.QPixmap("d.png"))
        # self.gridLayout_map.addWidget(self.label_me,0,0,1,1)



        self.tabWidget.addTab(self.tab2, "")
        self.verticalLayout.addWidget(self.tabWidget)
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 515, 22))
        self.menubar.setObjectName("menubar")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        self.tabWidget.setCurrentIndex(0)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def savet(self):
        matplotlib.use('Agg')
        config = {
            'host': '127.0.0.1',
            'port': 3306,
            'user': 'root',
            'password': '123',
            'db': 'wjy1',
            'charset': 'utf8mb4',
            'cursorclass': pymysql.cursors.DictCursor,
        }
        conn = pymysql.connect(**config)

        sql = 'select * from patent_data'

        cus = conn.cursor()
        cus.execute(sql)
        content = cus.fetchall()
        print(content)
        biaoqian = {}
        for i in range(len(content)):
            for j in content[i]:
                if j == 'Jurisdiction':
                    if content[i][j] in biaoqian:
                        biaoqian[content[i][j]] += 1
                    else:
                        biaoqian[content[i][j]] = 1
                else:
                    continue
        x = []
        y = []
        for a in biaoqian:
            x.append(a)
            y.append(biaoqian[a])

        plt.xticks([i for i in range(len(x))], x)
        plt.bar(x, y, 0.8, color=['brown', 'orange', 'darkgreen', 'navy'])
        plt.xlabel('country', color='black')

        plt.ylabel('amount', color='black')
        savefig('d.png')
        plt.close()


    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Statistical Analysis"))
        self.label_5.setText(_translate("MainWindow", "The number of patents in the calendar year"))
        self.label.setText(_translate("MainWindow", "starting year"))
        self.pushButton.setText(_translate("MainWindow", "Generate histogram"))
        self.label_2.setText(_translate("MainWindow", "terminate the year"))
        self.pushButton_2.setText(_translate("MainWindow", "Generate Pie Chart"))
        self.pushButton_3.setText(_translate("MainWindow", "Clear"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab1),
                                           _translate("MainWindow", "The number of patents in the calendar year"))
        self.label_4.setText(_translate("MainWindow", "Country Patent Quantitative Chart"))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab2),
                                           _translate("MainWindow", "Country Patent Quantitative Graph"))

