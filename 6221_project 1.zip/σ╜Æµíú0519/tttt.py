import pymysql.cursors
import matplotlib.pyplot as plt

#连接数据的配置信息
config = {
          'host':'127.0.0.1',
          'port':3306,
          'user':'root',
          'password':'123',
          'db':'test',
          'charset':'utf8mb4',
          'cursorclass':pymysql.cursors.DictCursor,
          }



#连接数据库
connection = pymysql.connect(**config)
yearStart=input('start year')
yearEnd=input('end year')
result=1
try:
    with connection.cursor() as cursor:
            #先把要执行的语句写成string格式存在sql变量下，其中%s代表要用元祖赋值的值
        sql = 'select * from patent_data where Publication_Year>=%s and Publication_Year<=%s;'
            #excute就是执行了
        cursor.execute(sql,(yearStart,yearEnd))
        result = cursor.fetchall()
        connection.commit()


except:
    result=False
    print('search wrong')


year={}


for a in result:
    if a['Publication_Year'] in year:
        year[a['Publication_Year']]+=1
    else:
        year[a['Publication_Year']] = 1
x=sorted(year,reverse = True)
y=[]

for a in x:
    y.append(year[a])




yearStart=int(yearStart)
yearEnd=int(yearEnd)


plt.xticks([i for i in range(yearEnd,yearStart-1,-1)], [str(i) for i in range(yearEnd,yearStart-1,-1)])

plt.bar(x,y,0.8,color=['brown','orange','darkgreen','navy'])
plt.xlabel('Publication_Year',color='black')

plt.ylabel('amount',color='black')







connection.close();